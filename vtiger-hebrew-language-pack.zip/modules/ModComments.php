<?php 

    /*+**********************************************************************************
     * The contents of this file are subject to the vtiger CRM Public License Version 1.0
     * ("License"); You may not use this file except in compliance with the License
     * The Original Code is: vtiger CRM Open Source
     * The Initial Developer of the Original Code is vtiger.
     * Portions created by vtiger are Copyright (C) vtiger.
     * Portions created by Ido Kobelkowsky are Copyright (C) yalla ya!.
     * All Rights Reserved.
     *  ********************************************************************************
     *  Author       : Ido Kobelkowsky
     ************************************************************************************/
    
$languageStrings = array (
  'SINGLE_ModComments' => 'תגובה',
  'LBL_RECORDS_LIST' => 'רשימת הערות',
  'LBL_MODCOMMENTS_INFORMATION' => 'הערות',
  'LBL_OTHER_INFORMATION' => 'מידע אחר',
  'LBL_ADDING_COMMENT' => 'הוספת תגובה',
  'LBL_WRITE_YOUR_COMMENT_HERE' => 'הזן הערות כאן',
  'Comment' => 'תגובה',
  'Creator' => 'בורא',
  'Related To Comments' => 'קשור ל',
  'LBL_COMMENTED_AT' => 'הגיב ב',
);
